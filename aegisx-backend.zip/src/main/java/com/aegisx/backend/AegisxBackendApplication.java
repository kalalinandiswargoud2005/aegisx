package com.aegisx.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AegisxBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AegisxBackendApplication.class, args);
	}

}
